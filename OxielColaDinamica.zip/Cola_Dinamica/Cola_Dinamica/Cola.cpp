#include "Cola.h"
Cola::Cola() {

}
Cola::~Cola() {

}
void Cola::encolar(Nodo*& inicio, Nodo*& fin) {
    Nodo* Elemento = new Nodo; //Creacion del nodo      
    if (inicio == NULL) {

        inicio = fin = Elemento; //Le asigno la direccion del primer nodo          
        cout << "Codigo: "; cin >> Elemento->dato.Codigo;
        cout << "Nombres: s"; cin >> Elemento->dato.Nombre;
        cout << "Carrera: "; cin >> Elemento->dato.Carrera;


    }
    else {

        fin->sig = Elemento; //Asigno el puntero del anterior elemento al nuevo

        fin = Elemento; //Cambio la direccion del ultimo nodo creado 

        cout << "Codigo: "; cin >> Elemento->dato.Codigo;
        cout << "Nombres: "; cin >> Elemento->dato.Nombre;
        cout << "Carrera: "; cin >> Elemento->dato.Carrera; cout << endl;

    }
}
void Cola::desencolar(Nodo*& inicio) {
    if (inicio != NULL) {
        cout << "Codigo: " << inicio->dato.Codigo << endl;
        cout << "Nombres: " << inicio->dato.Nombre << endl;
        cout << "Carrera: " << inicio->dato.Carrera << endl;
        inicio = inicio->sig; // Cambio Inicio al siguiente nodo
    }
    else {
        cout << "La cola se encuentra vacia" << endl;
    }
}

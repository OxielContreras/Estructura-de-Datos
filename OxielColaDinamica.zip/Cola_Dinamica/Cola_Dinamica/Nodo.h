#pragma once
#include "Dato.h"
class Nodo{
public:
	Dato dato;
	Nodo* sig;
	Nodo() {
		sig = NULL;
	}
};

